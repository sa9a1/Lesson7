require 'test_helper'

class BodyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
