# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '024bd1a503fd668e4a8e9bd737684cbd580eb0af1d114f7db41135d82e5178da3645fb980442d08483452991d2aff69fcd29e27cd8f6f097e45c1795be2f4583'